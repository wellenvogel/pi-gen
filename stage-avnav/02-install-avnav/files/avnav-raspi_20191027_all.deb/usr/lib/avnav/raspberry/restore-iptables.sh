#!/usr/bin/env bash
iptables-restore < /etc/iptables.ipv4.nat
