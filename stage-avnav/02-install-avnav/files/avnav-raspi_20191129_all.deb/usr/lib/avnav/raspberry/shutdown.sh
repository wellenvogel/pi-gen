#!/bin/sh
sudo -n shutdown -P